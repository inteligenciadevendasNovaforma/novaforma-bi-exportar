# Relatório de Pedidos — visual completo

Fonte e pacote do visual Novaforma para o repositório existente `inteligenciadevendasNovaforma/novaforma-bi-exportar`, na pasta `relatorio-pedidos/`.

O visual aponta para a página existente:
https://inteligenciadevendasnovaforma.github.io/novaforma-bi-exportar/download-page/

O GUID e a versão do visual foram preservados: `novaformaPedidosHTMLA41E65D7C9B64E03A822510202600101`, `1.0.0.0`, API Power BI `5.11.0`. O autor continua Novaforma. Não há dados, modelo semântico, PBIX ou fixtures de clientes neste pacote.

## Compilar em qualquer pasta

Com Node.js 18 ou superior e npm:

```sh
npm ci
npm test
npm run build
```

`package-lock.json` fixa `esbuild 0.25.11` e `fflate 0.8.2`, com integridade dos pacotes e binários opcionais de plataforma do esbuild. O build usa as dependências locais, sem caminhos do workspace de origem. Não precisa de Power BI Desktop para compilar.

Opcionalmente, um ambiente de desenvolvimento que já possua essas dependências pode definir `NF_BUILD_DEPENDENCIES` como o diretório que contém seu `package.json` e `node_modules`. O padrão permanece a instalação própria por `npm ci`.

O build gera `capabilities.json` e `dist/`: pacote `.pbiviz`, `resource.json`, manifesto `package.json`, JavaScript e preview. As licenças de terceiros estão em `licenses/`. O pacote compilado já está incluído; a reconstrução não muda a regra financeira, os filtros ou as colunas.

## Integrar ao relatório

Importe `dist/novaformaPedidosHTMLA41E65D7C9B64E03A822510202600101.pbiviz` no Power BI. O visual depende do contrato de dados existente; não cria medidas nem tabelas. Vincule as três medidas `config`, `body`, `footer` e as três colunas opcionais de domínio `optionField`, `optionValue`, `optionBlank`.

`config` contém a origem, visão, paginação, cabeçalhos, larguras, tipos numéricos, campos de filtro, versão/quantidade esperada de opções e períodos. `body` contém as linhas HTML da página; `footer` contém os totais integrais do filtro. O modelo continua responsável pelos cálculos. As opções completas são recebidas por segmentos e verificadas contra `expectedOptions`; domínios incompletos não são silenciosamente truncados.

O estado persistido `general.stateJSON` contém os filtros canônicos; `general.stateFilter` aplica esse estado ao próprio visual. `general.nativeNavigationGap` preserva a geometria de navegação do relatório existente. Mantenha os controles técnicos de visão/página e os alvos de campos definidos no modelo desse relatório. A importação isolada não configura esses objetos nem os botões nativos de navegação.

## Dados para exportar

A configuração de formatação `export.production` escolhe explicitamente a página existente; `false` mantém DownloadService no Desktop. O padrão não foi alterado. Permissões de exportação e acesso à página precisam estar liberadas pelo Power BI; não há desvio de bloqueio administrativo.

A coleta percorre todas as páginas do recorte, valida contagens, filtros, versão, cabeçalhos, tipos e totais antes de gerar um único XLSX. Códigos permanecem texto e medidas permanecem números. Mudanças de recorte invalidam a preparação; o usuário pode cancelar sem receber arquivo parcial. A página original é restaurada quando isso preserva os filtros atuais.

Na produção, o usuário prepara o arquivo e clica para abrir a página. Arquivos pequenos usam fragmento `#d=...`; grandes usam **Copiar dados → Abrir página de download → Colar dados**, com prefixo `NFXLSX1.`. O link completo é limitado a 2.500 caracteres, sem truncar linhas; o XLSX tem limite de 30 MiB. `export.pagesClipboardReady` deve ficar `false` até o receptor NFXLSX1 da página publicada ser verificado. Os bytes XLSX são transportados sem reconstrução de células ou recálculo na página.

Publicar o código do visual não publica automaticamente a página receptora, não ativa o relatório e não comprova o fluxo no Power BI Service. Essas etapas devem ser verificadas separadamente no ambiente autorizado.

## Verificação desta entrega

O teste incluído usa apenas dados sintéticos em memória e verifica o URL existente, permissões e preservação dos bytes no transporte pequeno/grande. O manifesto de entrega registra hashes e a comparação com a fonte funcional. Os testes anteriores do projeto com dados reais não foram copiados para este repositório.
