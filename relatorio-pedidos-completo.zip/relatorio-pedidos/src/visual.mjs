import {esc,basic,dateFilter,selections,dateSelection,extractRows,csvLine,normalized,validateConfig,targetMatches,selfFilters,filtersForField} from './core.mjs';
import css from './style.css';
import logo from './logo.svg';
import {makeXlsx,base64,totalsFromHtml} from './xlsx.mjs';
import {helpContent} from './help.mjs';
import {analysisPeriodText} from './period.mjs';
import {EXPORT_MODES,DOWNLOAD_PAGE,assertExportPermissions,prepareDownloadPlan,copyPlanPayload,launchDownloadPlan,exportFingerprint} from './download_bridge.mjs';

let orderPanelSequence=0;

export class Visual {
  constructor(options){
    this.host=options.host;this.element=options.element;this.filters=[];this.searches={};this.openFields=new Set();this.waiters=[];this.pending=false;this.sequence=0;this.optionRows=new Map();this.optionCache=null;this.optionLoading=false;
    this.abort=new AbortController();
    this.element.innerHTML=`<style>${css}</style><main class="nf-page"><header class="nf-header"><div class="nf-logo" aria-label="Novaforma">${logo.replace(/<\?xml[^>]*>/,'')}</div><div class="nf-signature">Inteligência de Mercado</div><h1 class="nf-title"></h1><button class="nf-export" data-action="export">Dados para exportar ▾</button><button class="nf-help" data-action="help" title="Ajuda para usar filtros, tabelas e exportação" aria-label="Abrir Dúvidas sobre o relatório" aria-haspopup="dialog" aria-expanded="false"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9.5 9a2.5 2.5 0 1 1 4.1 1.9c-1 .7-1.6 1-1.6 2.6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="17" r="1" fill="currentColor"/></svg><span>Dúvidas</span></button></header><div class="nf-nav" style="left:24px" data-origin="Vendido" aria-hidden="true">Vendido</div><div class="nf-nav" style="left:212px" data-origin="Em Aberto" aria-hidden="true">Em Aberto</div><div class="nf-nav" style="left:400px" data-origin="Bloqueado" aria-hidden="true">Bloqueado</div><button class="nf-tab" style="left:588px;width:184px" data-view="Pedidos">Lista de pedidos</button><button class="nf-tab" style="left:784px;width:196px" data-view="Materiais">Lista por material</button><button class="nf-filter-toggle" data-action="filters">⌕ Filtros</button><div class="nf-intro"></div><div class="nf-status" role="status" aria-live="polite"></div><label class="nf-pagination">Página <select aria-label="Página da lista" data-page></select><span class="nf-pages"></span></label><section class="nf-body" role="region" tabindex="0" aria-label="Lista de pedidos e materiais"></section><section class="nf-footer" aria-label="Totais integrais do filtro"></section><section class="nf-overlay" hidden role="dialog" aria-modal="true" aria-label="Filtros"></section></main>`;
    this.root=this.element.querySelector('.nf-page');this.overlay=this.root.querySelector('.nf-overlay');
    this.orderPanel=document.createElement('section');this.orderPanel.className='nf-order-panel';this.orderPanel.hidden=true;this.orderPanel.id='nf-order-panel-'+(++orderPanelSequence);this.orderPanel.setAttribute('role','dialog');this.orderPanel.setAttribute('aria-modal','false');this.orderPanel.setAttribute('aria-label','Detalhes do pedido');
    this.orderPanel.innerHTML='<div class="nf-order-heading"><h2></h2><button type="button" data-action="close-order-detail" title="Fechar os detalhes do pedido" aria-label="Fechar os detalhes do pedido">Fechar ×</button></div><div class="nf-order-content" role="region" aria-label="Resumo e materiais do pedido" tabindex="0"></div>';this.root.append(this.orderPanel);
    for(const event of ['pointerover','pointerout','pointermove','focusin','focusout'])this.root.addEventListener(event,e=>this.orderDetailEvent(e),{signal:this.abort.signal});
    this.element.ownerDocument.addEventListener('scroll',e=>{if(!this.orderPanel.contains(e.target))this.hideOrderDetail();},{capture:true,signal:this.abort.signal});
    this.element.ownerDocument.addEventListener('keydown',e=>{if(e.key==='Escape'&&!this.orderPanel.hidden)this.orderDetailKey(e);},{signal:this.abort.signal});
    this.root.addEventListener('click',e=>this.click(e),{signal:this.abort.signal});
    this.root.addEventListener('change',e=>this.change(e),{signal:this.abort.signal});
    this.root.addEventListener('input',e=>this.input(e),{signal:this.abort.signal});
    this.root.addEventListener('toggle',e=>{if(e.target.matches('details[data-field]')){const k=Number(e.target.dataset.field);e.target.open?this.openFields.add(k):this.openFields.delete(k);}},{capture:true,signal:this.abort.signal});
    this.root.addEventListener('keydown',e=>this.keydown(e),{signal:this.abort.signal});
    this.status('Aguardando config, body e footer do modelo.');
  }
  update(options){
    this.hideOrderDetail();this.orderHoverBlocked=this.orderPointer;
    this.host.eventService?.renderingStarted(options);
    try{
      const layoutGeneral=options.dataViews?.[0]?.metadata?.objects?.general;
      if(layoutGeneral&&Object.prototype.hasOwnProperty.call(layoutGeneral,'nativeNavigationGap'))this.nativeNavigationGap=layoutGeneral.nativeNavigationGap===true;
      const canvasHeight=this.nativeNavigationGap?606:720;
      this.root.classList.toggle('nf-navigation-gap',!!this.nativeNavigationGap);this.root.style.height=canvasHeight+'px';
      const scale=Math.min((options.viewport?.width||1280)/1280,(options.viewport?.height||canvasHeight)/canvasHeight);this.root.style.transform=`scale(${scale})`;
      const dv=options.dataViews?.[0],t=dv?.table;
      // Desktop also emits empty tables with the Data flag during streaming.
      // No payload proves neither missing bindings nor an empty business set:
      // preserve pending/filter/domain state until an actual ROOT row arrives.
      if(!dv||!t||!t.rows?.length){
        if(!this.config)this.status('Aguardando os dados do relatório…');
        this.host.eventService?.renderingFinished(options);return;
      }
      const exportOptions=dv.metadata?.objects?.export||{};
      this.exportSettings={production:exportOptions.production===true,pagesClipboardReady:exportOptions.pagesClipboardReady===true};
      const general=dv.metadata?.objects?.general;
      if(general&&Object.prototype.hasOwnProperty.call(general,'stateJSON')){
        if(typeof general.stateJSON!=='string')throw Error('O estado JSON dos filtros deve ser texto.');
        const restored=JSON.parse(general.stateJSON);
        if(!Array.isArray(restored)||restored.some(f=>!f?.target?.table||!f?.target?.column))throw Error('O estado JSON dos filtros não contém filtros de coluna válidos.');
        const stamp=JSON.stringify(restored);
        if(stamp!==this.metadataJSONState)this.filters=restored;
        this.metadataJSONState=stamp;this.hasCanonicalState=true;
      }else if(!this.hasCanonicalState&&general&&Object.prototype.hasOwnProperty.call(general,'stateFilter')){
        const raw=general.stateFilter;const plain=raw==null?raw:JSON.parse(JSON.stringify(raw));const restored=selfFilters(plain);
        const stamp=JSON.stringify(restored);
        // An unchanged metadata echo must not undo local SELF changes. A new
        // persisted state remains authoritative for bookmark/external restore.
        if(stamp!==this.metadataState)this.filters=restored;
        this.metadataState=stamp;
      }else if(!this.hasCanonicalState&&options.jsonFilters?.length&&!this.pending)this.filters=options.jsonFilters;
      const index=role=>t.columns.findIndex(c=>c.roles?.[role]);const indexes=['config','body','footer'].map(index);if(indexes.some(i=>i<0))throw Error('Vincule config, body e footer.');
      const optionIndexes=['optionField','optionValue','optionBlank'].map(index),streaming=optionIndexes.every(i=>i>=0);
      if(!streaming&&(dv.metadata?.segment||t.rows.length!==1))throw Error('Vincule as opções por linhas ou forneça exatamente uma linha com config, body e footer.');
      let rootRow=streaming?t.rows.find(row=>row[optionIndexes[0]]==='__root'):t.rows[0];
      // fetchMoreData(true) normally aggregates rows. Retain the ROOT payload
      // for a host that delivers append/delta batches instead, within this load.
      if(!rootRow&&streaming&&this.optionLoading&&this.optionRootRow&&options.operationKind!==0)rootRow=this.optionRootRow;
      if(!rootRow&&streaming){
        for(const row of t.rows)this.captureOption(row,optionIndexes);
        this.optionLoading=true;this.status('Carregando opções completas de filtro…');
        if(dv.metadata?.segment&&this.requestMoreOptions()){this.host.eventService?.renderingFinished(options);return;}
        throw Error('A linha __root com os dados do relatório não foi recebida. Nenhuma lista parcial será usada.');
      }
      const c=validateConfig(JSON.parse(rootRow[indexes[0]]));
      const body=String(rootRow[indexes[1]]??''),footer=String(rootRow[indexes[2]]??'');
      if(streaming){
        if(!Number.isInteger(c.expectedOptions)||c.expectedOptions<1)throw Error('expectedOptions deve contar todas as opções, incluindo __root.');
        const version=this.optionsKey(c);
        if(this.optionVersion!==version){this.optionRows.clear();this.optionSnapshot=null;this.optionCache=null;this.hydratedOptions=null;this.optionVersion=version;}
        this.optionRootRow=rootRow;
        this.captureOptions(t.rows,optionIndexes,options.operationKind===0&&this.optionLoading);
        if(this.optionCache?.version===version){this.hydrateOptions(c,this.optionCache.rows);this.optionLoading=false;}
        else{
          this.optionLoading=!!dv.metadata?.segment;
          if(!this.optionLoading){
            if(this.optionRows.size!==c.expectedOptions)throw Error(`Opções incompletas: recebidas ${this.optionRows.size} de ${c.expectedOptions}. Filtros indisponíveis; nenhuma opção será omitida silenciosamente.`);
            this.optionCache={version,rows:[...this.optionRows.values()]};this.hydrateOptions(c,this.optionCache.rows);
          }
        }
      }
      // Describe the confirmed data context, never a local queued filter edit.
      if(!this.appliedPeriodFilters||!this.pending||options.type===undefined||(options.type&2)!==0)this.appliedPeriodFilters=this.metadataJSONState!==undefined?JSON.parse(this.metadataJSONState):JSON.parse(JSON.stringify(this.filters));
      this.config=c;this.body=body;this.footer=footer;this.sequence++;this.pending=false;
      this.checkExportContext();
      this.render();
      const waiters=this.waiters.slice();for(const w of waiters)if(w.page===c.page&&this.sequence>w.sequence){clearTimeout(w.timer);this.waiters.splice(this.waiters.indexOf(w),1);w.resolve({config:c,body,fingerprint:this.currentExportFingerprint()});}
      if(this.overlayMode==='filters')this.renderFilters();
      if(streaming&&this.optionLoading){this.status(`Carregando opções: ${this.optionRows.size.toLocaleString('pt-BR')} de ${c.expectedOptions.toLocaleString('pt-BR')}…`);if(!this.requestMoreOptions())throw Error('O Power BI interrompeu a carga das opções antes do total. Filtros indisponíveis; reduza o domínio ou verifique o limite de dados do visual.');}
      this.host.eventService?.renderingFinished(options);
      if(this.queuedState){const state=this.queuedState;this.queuedState=null;this.filters=state;this.submitState(state);}
    }catch(e){this.optionError=e.message;this.status('Erro: '+e.message);if(this.overlayMode==='filters')this.renderFilters();this.rejectWaiters(e);this.host.eventService?.renderingFailed(options,e.message);}
  }
  requestMoreOptions(){if(typeof this.host.fetchMoreData!=='function')throw Error('Este host não oferece a API para carregar todas as opções.');return this.host.fetchMoreData(true)!==false;}
  optionsKey(config){return JSON.stringify([String(config.optionsVersion??''),config.expectedOptions,(config.fields||[]).map(f=>[f.key,f.type,f.valueType,f.table,f.column,f.targets??null])]);}
  captureOptions(rows,indexes,newQuery=false){
    const [f,v,b]=indexes,aggregated=rows[0]?.[f]==='__root';let start=0;
    if(aggregated&&!this.optionSnapshot&&this.optionCache){
      // A delta load has no positional snapshot. Validate every supplied option
      // against the complete cached set before reusing its hydrated domains.
      const known=rows.every(row=>this.optionRows.has(JSON.stringify([String(row[f]),row[v]??'',row[b]===true||row[b]===1||String(row[b]).toLowerCase()==='true'])));
      if(!known){this.optionRows.clear();this.optionCache=null;this.hydratedOptions=null;}
    }
    if(aggregated&&this.optionSnapshot&&!newQuery){
      const previous=this.optionSnapshot,n=Math.min(previous.length,rows.length);let same=true;
      // Validate the complete received prefix, not only length or two borders.
      // Primitive comparisons avoid recreating JSON keys/Map entries for it.
      for(let i=0;i<n;i++){const row=rows[i],old=previous[i];if(row[f]!==old[0]||row[v]!==old[1]||row[b]!==old[2]){same=false;break;}}
      if(same&&(rows.length>=previous.length||this.optionCache?.version===this.optionVersion))start=n;
      else{this.optionRows.clear();this.optionCache=null;this.hydratedOptions=null;this.optionSnapshot=null;}
    }else if(aggregated&&newQuery){this.optionRows.clear();this.optionCache=null;this.hydratedOptions=null;this.optionSnapshot=null;}
    if(aggregated){
      if(!this.optionSnapshot)this.optionSnapshot=[];
      for(let i=start;i<rows.length;i++){const row=rows[i];this.captureOption(row,indexes);this.optionSnapshot[i]=[row[f],row[v],row[b]];}
    }else{for(const row of rows)this.captureOption(row,indexes);this.optionSnapshot=null;}
  }
  captureOption(row,indexes){const [f,v,b]=indexes,field=row[f];if(field===undefined||field===null)throw Error('Uma opção não contém Campo.');const item={field:String(field),value:row[v]??'',blank:row[b]===true||row[b]===1||String(row[b]).toLowerCase()==='true'};this.optionRows.set(JSON.stringify([item.field,item.value,item.blank]),item);}
  hydrateOptions(config,rows){
    const key=this.optionsKey(config);
    if(this.hydratedOptions?.key===key){for(const f of config.fields||[])if(f.type!=='date')f.values=this.hydratedOptions.values.get(f.key);this.optionError=null;return;}
    const fields=new Map((config.fields||[]).map(f=>[String(f.key),f]));for(const f of fields.values())if(f.type!=='date')f.values=[];
    for(const item of rows){if(item.field==='__root')continue;const f=fields.get(item.field);if(!f)throw Error(`Campo de opção desconhecido: ${item.field}. Use os mesmos keys dos metadados.`);let value=item.blank?null:item.value;if(value!==null&&f.valueType==='int64'){value=Number(value);if(!Number.isSafeInteger(value))throw Error(`Código inteiro fora da precisão segura de JavaScript: ${item.value}. Configure o campo como texto no modelo.`);}else if(value!==null&&['bool','boolean'].includes(f.valueType)){if(!['true','false','1','0'].includes(String(value).toLowerCase()))throw Error('Valor booleano de opção inválido.');value=['true','1'].includes(String(value).toLowerCase());}else if(value!==null)value=String(value);f.values.push({value,label:item.blank?'(Em branco)':String(item.value)});}
    this.optionError=null;
    this.hydratedOptions={key,values:new Map([...fields.values()].filter(f=>f.type!=='date').map(f=>[f.key,f.values]))};
  }
  status(message){this.root.querySelector('.nf-status').textContent=message;this.root.querySelector('.nf-intro').hidden=!!message&&this.root.classList.contains('nf-has-analysis-period');}
  render(){
    this.hideOrderDetail();this.orderHoverBlocked=this.orderPointer;
    const c=this.config;this.root.querySelector('.nf-title').innerHTML='<span>Relatório de Pedidos</span><span class="nf-title-context">'+esc(c.title||c.origin)+'</span>';
    for(const n of this.root.querySelectorAll('[data-origin]'))n.classList.toggle('active',n.dataset.origin===c.origin);
    for(const n of this.root.querySelectorAll('[data-view]')){n.hidden=c.showViews===false;n.style.display=c.showViews===false?'none':'';n.classList.toggle('active',n.dataset.view===c.view);n.setAttribute('aria-pressed',String(n.dataset.view===c.view));n.disabled=!!this.job;}
    const intro=this.root.querySelector('.nf-intro'),period=analysisPeriodText(c,this.appliedPeriodFilters);
    this.root.classList.toggle('nf-has-analysis-period',!!period);
    intro.textContent=period||(c.view==='Pedidos'?'Lista de pedidos · uma linha por pedido.':'Lista por material · uma linha por pedido e código do material.');
    intro.title=period;intro.setAttribute('aria-label',period?'Período aplicado à análise':'Descrição da lista');
    const select=this.root.querySelector('[data-page]');select.innerHTML=Array.from({length:c.pages},(_,i)=>`<option value="${i+1}" ${c.page===i+1?'selected':''}>${i+1}</option>`).join('');select.disabled=!!this.job;
    this.root.querySelector('.nf-pages').textContent=`de ${c.pages}`;
    const mount=this.root.querySelector('.nf-body');
    // Host formatting/domain updates are not user navigation. Compare filter
    // semantics independently of object keys, predicate order and In order.
    const canonical=value=>Array.isArray(value)?'['+value.map(canonical).sort().join(',')+']':value&&typeof value==='object'?'{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}':JSON.stringify(value);
    const scrollContext=JSON.stringify([c.origin,c.view,c.page,c.headers,c.widths,canonical(this.filters)]);
    const retainScroll=this.renderedScrollContext===scrollContext,scrollLeft=mount.scrollLeft,scrollTop=mount.scrollTop;
    const markup=c.count?`<table class="nf-table" style="width:${c.widths.reduce((a,b)=>a+b,0)}px"><colgroup>${c.widths.map(w=>`<col style="width:${w}px">`).join('')}</colgroup><thead><tr>${c.headers.map(h=>`<th scope="col" title="${esc(h)}">${esc(h)}</th>`).join('')}</tr></thead><tbody>${this.body}</tbody></table>`:'<div class="nf-empty">Sem dados para os filtros selecionados.</div>';
    if(markup!==this.renderedBodyMarkup){mount.innerHTML=markup;this.renderedBodyMarkup=markup;}
    for(const row of mount.querySelectorAll('.nf-table>tbody>tr')){const cell=row.cells[0],template=row.querySelector('template.nf-order-detail');if(!cell||!template?.content?.textContent?.trim())continue;cell.dataset.orderAnchor='true';cell.classList.add('nf-order-anchor');cell.tabIndex=0;cell.setAttribute('aria-haspopup','dialog');cell.setAttribute('aria-controls',this.orderPanel.id);cell.setAttribute('aria-expanded','false');cell.setAttribute('aria-label',`Pedido ${cell.textContent.trim()}. Detalhes do pedido; pressione Enter para acessar.`);}
    this.renderFooter();
    mount.scrollLeft=retainScroll?scrollLeft:0;mount.scrollTop=retainScroll?scrollTop:0;
    this.renderedScrollContext=scrollContext;
    this.root.querySelector('.nf-export').disabled=!!this.job||!c.count||this.optionLoading||!!this.optionError;
    this.root.querySelector('.nf-filter-toggle').disabled=!!this.job;
    this.status(this.job?`Exportando página ${c.page} de ${c.pages}…`:'');
  }
  renderFooter(){
    const c=this.config,footer=this.root.querySelector('.nf-footer');
    // Presentation only: retain the original HTML for the existing Excel path.
    const totals=totalsFromHtml(this.footer,c.headers);
    footer.innerHTML='<h2>Totais do filtro</h2><dl class="nf-totals-grid">'+totals.map(([label,value])=>`<div class="nf-total"><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`).join('')+'</dl>'+`<p class="nf-totals-note">${c.count.toLocaleString('pt-BR')} linhas no filtro · Página ${c.page} de ${c.pages} · Os totais incluem todas as páginas.</p>`;
    // Reserve actual space for wrapped blocks instead of scrolling totals.
    footer.style.height='auto';
    const height=Math.max(68,footer.offsetHeight);
    footer.style.height=height+'px';
    this.root.querySelector('.nf-body').style.height=Math.max(0,(this.nativeNavigationGap?606:720)-height-4-(this.nativeNavigationGap?70:148))+'px';
  }
  orderDetailEvent(event){
    const cell=event.target.closest?.('[data-order-anchor]'),inside=this.orderPanel.contains(event.target);
    if(event.type.startsWith('pointer')){
      this.orderPointer={x:event.clientX,y:event.clientY};
      if(this.orderHoverBlocked){if(event.clientX===this.orderHoverBlocked.x&&event.clientY===this.orderHoverBlocked.y)return;this.orderHoverBlocked=null;if(cell)this.showOrderDetail(cell);}
      if(event.type==='pointermove')return;
    }else if(event.type==='focusin')this.orderHoverBlocked=null;
    if(event.type==='pointerover'||event.type==='focusin'){
      if(inside){clearTimeout(this.orderCloseTimer);return;}
      if(cell&&cell!==this.orderFocusSuppressed){if(event.relatedTarget&&cell.contains(event.relatedTarget))return;this.showOrderDetail(cell);}
    }else if(cell||inside){
      const next=event.relatedTarget;
      if(next&&(this.orderPanel.contains(next)||this.orderAnchor?.contains(next))){clearTimeout(this.orderCloseTimer);return;}
      clearTimeout(this.orderCloseTimer);this.orderCloseTimer=setTimeout(()=>{const focus=this.element.ownerDocument.activeElement;if(focus===this.orderAnchor||this.orderPanel.contains(focus))return;this.hideOrderDetail();},180);
    }
  }
  showOrderDetail(cell){
    if(this.job||!this.overlay.hidden||!cell?.isConnected)return;
    clearTimeout(this.orderCloseTimer);
    if(this.orderAnchor===cell&&!this.orderPanel.hidden)return;
    const template=cell.parentElement.querySelector('template.nf-order-detail');if(!template)return;
    this.hideOrderDetail();this.orderAnchor=cell;
    const content=this.orderPanel.querySelector('.nf-order-content'),fragment=template.content.cloneNode(true);
    // The model supplies escaped, static HTML. Keep the detail non-interactive:
    // no scripts, forms, external resources or event handlers from a template.
    for(const node of fragment.querySelectorAll('script,style,iframe,object,embed,link,meta,base,form,input,button,textarea,select,svg,math,img,video,audio,template'))node.remove();
    for(const node of fragment.querySelectorAll('*'))for(const attr of [...node.attributes])if(/^on/i.test(attr.name)||['href','src','srcset','action','formaction','autofocus','tabindex','contenteditable'].includes(attr.name.toLowerCase()))node.removeAttribute(attr.name);
    content.replaceChildren(fragment);content.scrollTop=0;content.scrollLeft=0;
    const order=cell.textContent.trim();this.orderPanel.querySelector('h2').textContent=`Pedido ${order}`;this.orderPanel.setAttribute('aria-label',`Detalhes do pedido ${order}`);cell.setAttribute('aria-expanded','true');this.orderPanel.hidden=false;
    const root=this.root.getBoundingClientRect(),anchor=cell.getBoundingClientRect(),sx=root.width/this.root.offsetWidth||1,sy=root.height/this.root.offsetHeight||1;
    const x=(anchor.left-root.left)/sx,top=(anchor.top-root.top)/sy,bottom=(anchor.bottom-root.top)/sy,width=Math.min(900,this.root.clientWidth-24);
    this.orderPanel.style.width=width+'px';this.orderPanel.style.maxHeight='450px';
    const natural=this.orderPanel.offsetHeight,below=this.root.clientHeight-bottom-20,above=top-20,useBelow=below>=Math.min(250,natural)||below>=above;
    this.orderPanel.style.maxHeight=Math.min(450,Math.max(100,useBelow?below:above))+'px';
    const height=this.orderPanel.offsetHeight,y=useBelow?bottom+8:top-height-8;
    this.orderPanel.style.left=Math.max(12,Math.min(x,this.root.clientWidth-width-12))+'px';this.orderPanel.style.top=Math.max(12,Math.min(y,this.root.clientHeight-height-12))+'px';
  }
  hideOrderDetail(restoreFocus=false){
    clearTimeout(this.orderCloseTimer);if(!this.orderPanel)return;
    const cell=this.orderAnchor,focused=this.orderPanel.contains(this.element.ownerDocument.activeElement);
    this.orderPanel.hidden=true;this.orderAnchor=null;cell?.setAttribute('aria-expanded','false');this.orderPanel.querySelector('.nf-order-content').replaceChildren();
    if(restoreFocus&&focused&&cell?.isConnected){this.orderFocusSuppressed=cell;cell.focus({preventScroll:true});this.orderFocusSuppressed=null;}
  }
  orderDetailKey(event){
    if(event.key==='Escape'&&!this.orderPanel.hidden){event.preventDefault();event.stopPropagation();this.hideOrderDetail(true);return true;}
    const cell=event.target.closest?.('[data-order-anchor]');if(cell&&(event.key==='Enter'||event.key===' ')){event.preventDefault();this.showOrderDetail(cell);if(!this.orderPanel.hidden)this.orderPanel.querySelector('.nf-order-content').focus({preventScroll:true});return true;}
    return false;
  }
  apply(property,filter,reset=false){
    this.hideOrderDetail();
    const field=property.startsWith('field')?this.config.fields[Number(property.slice(5))]:null;
    const target=field||filter?.target||(property==='viewFilter'?{table:'d_HTML_Visao',column:'Visao'}:{table:property==='pageMateriaisFilter'?'d_HTML_Pagina_Materiais':'d_HTML_Pagina_Pedidos',column:'Pagina'});
    if(target){this.filters=this.filters.filter(f=>!targetMatches(f,target));if(filter)this.filters.push(...(field?filtersForField(field,filter):[filter]));}
    if(reset)for(const view of ['Pedidos','Materiais']){const table=view==='Materiais'?'d_HTML_Pagina_Materiais':'d_HTML_Pagina_Pedidos';this.filters=this.filters.filter(f=>!targetMatches(f,{table,column:'Pagina'}));this.filters.push(basic(table,'Pagina',[1]));}
    // One complete property update per user action. Sequential host calls can
    // race against a data update and drop the business selection in Desktop.
    this.checkExportContext();
    const state=this.filters.slice();if(this.pending){this.queuedState=state;return;}this.submitState(state);
  }
  submitState(state){this.pending=true;this.status('Atualizando os dados…');this.hasCanonicalState=true;this.host.persistProperties?.({merge:[{objectName:'general',selector:null,properties:{stateJSON:JSON.stringify(state)}}]});this.host.applyJsonFilter(state,'general','stateFilter',state.length?0:1);}
  pageProperty(view=this.config.view){return view==='Materiais'?'pageMateriaisFilter':'pagePedidosFilter';}
  applyPage(page,view=this.config.view){const table=view==='Materiais'?'d_HTML_Pagina_Materiais':'d_HTML_Pagina_Pedidos';this.apply(this.pageProperty(view),basic(table,'Pagina',[Number(page)]));}
  async click(event){
    const b=event.target.closest('button');if(!b)return;
    if(b.dataset.action==='export-copy'||b.dataset.action==='export-open'){
      try{const plan=this.downloadPlan;if(!plan)throw Error('O recorte mudou ou o arquivo não está pronto. Prepare o arquivo novamente.');const isCurrent=()=>this.downloadPlan===plan&&this.currentExportFingerprint()===this.downloadPlanFingerprint;if(b.dataset.action==='export-copy'){await copyPlanPayload(this.host,plan,event,{isCurrent});if(!isCurrent())throw Error('O recorte mudou. Prepare o arquivo novamente.');this.overlay.querySelector('[data-action="export-open"]').disabled=false;this.overlay.querySelector('.nf-progress').textContent='Arquivo copiado. Abra a página e use Colar dados.';}else{await launchDownloadPlan(this.host,plan,event,{isCurrent});this.overlay.querySelector('.nf-progress').textContent='Página de download aberta. Conclua o download no navegador.';}}
      catch(error){this.overlay.querySelector('.nf-progress').textContent=error.message;}return;
    }
    if(b.dataset.action==='close-order-detail'){this.hideOrderDetail(true);return;}
    if(this.job&&b.dataset.action!=='cancel-export')return;
    if(b.dataset.view&&!this.job){if(b.dataset.view!==this.config.view)this.apply('viewFilter',basic('d_HTML_Visao','Visao',[b.dataset.view]));return;}
    if(b.dataset.clearField!==undefined&&!this.job){this.apply('field'+b.dataset.clearField,null,true);return;}
    if(b.dataset.applyDate!==undefined&&!this.job){this.applyDate(Number(b.dataset.applyDate));return;}
    switch(b.dataset.action){
      case 'filters':if(!this.job)this.open('filters','Filtros');break;
      case 'help':this.open('help','Dúvidas');break;
      case 'export':if(!this.job&&!this.pending&&!this.optionLoading&&!this.optionError)this.open('export','Exportar dados');break;
      case 'close':if(!this.job)this.close();break;
      case 'export-current':await this.export(false);break;
      case 'export-all':await this.export(true);break;
      case 'export-download':await this.export(this.overlay.querySelector('[name="nf-scope"]:checked')?.value!=='page',{data:this.overlay.querySelector('[data-include-data]').checked,totals:this.overlay.querySelector('[data-include-totals]').checked});break;
      case 'cancel-export':if(this.job){this.job.cancelled=true;this.rejectWaiters(Error('Exportação cancelada.'));}break;
    }
  }
  change(e){
    if(this.job)return;
    if(e.target.matches('[data-page]')){this.applyPage(Number(e.target.value));return;}
    if(e.target.dataset.choice!==undefined){const index=Number(e.target.dataset.choice),field=this.config.fields[index];const selected=selections(this.filters,field).slice(),value=field.values[Number(e.target.dataset.index)].value;const i=selected.findIndex(v=>v===value);if(e.target.checked&&i<0)selected.push(value);if(!e.target.checked&&i>=0)selected.splice(i,1);this.apply('field'+index,selected.length?basic(field.table,field.column,selected):null,true);}
  }
  input(e){if(e.target.dataset.search!==undefined){const i=Number(e.target.dataset.search);this.searches[i]=e.target.value;this.renderValues(i);}}
  applyDate(index){const field=this.config.fields[index],start=this.overlay.querySelector(`[data-date-start="${index}"]`).value,end=this.overlay.querySelector(`[data-date-end="${index}"]`).value;if(start&&end&&start>end){this.status('A data inicial deve ser anterior à data final.');return;}this.apply('field'+index,start||end?dateFilter(field,start,end):null,true);}
  open(mode,label){this.hideOrderDetail();this.lastFocus=document.activeElement;this.overlayMode=mode;this.overlay.classList.toggle('nf-export-menu',mode==='export');this.overlay.classList.toggle('nf-help-dialog',mode==='help');this.overlay.hidden=false;this.overlay.setAttribute('aria-label',label);this.root.querySelector('.nf-help').setAttribute('aria-expanded',String(mode==='help'));if(mode==='filters')this.renderFilters();else if(mode==='help')this.overlay.innerHTML=helpContent(this.config);else this.renderExportMenu();this.overlay.scrollTop=0;this.overlay.querySelector('button,input,summary')?.focus();}
  renderExportMenu(){this.overlay.innerHTML='<button class="nf-close" data-action="close" aria-label="Fechar exportação">×</button><h2>Incluir no Excel</h2><label class="nf-export-choice"><input type="checkbox" data-include-data checked> Tabela em células editáveis</label><label class="nf-export-choice"><input type="checkbox" data-include-totals checked> Totais do filtro</label><div class="nf-export-scope"><label><input type="radio" name="nf-scope" value="all" checked> Todo o recorte</label><label><input type="radio" name="nf-scope" value="page"> Página atual</label></div><button class="nf-primary" data-action="export-download">Baixar Excel</button><p class="nf-export-note">Mantém códigos como texto e valores como números. O download exige autorização do Power BI. Limite de 30 MB.</p>';}
  close(){this.overlay.hidden=true;this.overlay.classList.remove('nf-export-menu','nf-help-dialog');this.root.querySelector('.nf-help').setAttribute('aria-expanded','false');this.overlayMode=null;this.lastFocus?.focus();}
  renderFilters(){
    if(!this.config){this.overlay.innerHTML='<button class="nf-close" data-action="close">Fechar ×</button><h2>Filtros</h2><p>Aguardando a configuração do modelo.</p>';return;}
    if(this.optionLoading||this.optionError){this.overlay.innerHTML='<button class="nf-close" data-action="close">Fechar ×</button><h2>Filtros</h2>'+`<p class="${this.optionError?'nf-error':'nf-progress'}">${esc(this.optionError||'Carregando todas as opções de filtro. Aguarde a conclusão para selecionar; nenhuma opção será truncada.')}</p>`;return;}
    const active=document.activeElement?.dataset?.search;
    this.overlay.innerHTML='<button class="nf-close" data-action="close">Fechar ×</button><h2>Filtros</h2><p>Use os campos abaixo para filtrar a lista. Pesquise pelo valor desejado.</p><div class="nf-filter-grid"></div>';
    const grid=this.overlay.querySelector('.nf-filter-grid');
    const filterOrder=['field0','field13','field4','field1','field8','field10','field5','field7','field9','field2','field14','field3','field6','field11'];
    const fieldsInDisplayOrder=[...(this.config.fields||[]).entries()].filter(([,f])=>f.key!=='field12').sort((a,b)=>(filterOrder.indexOf(a[1].key)<0?999:filterOrder.indexOf(a[1].key))-(filterOrder.indexOf(b[1].key)<0?999:filterOrder.indexOf(b[1].key)));
    for(const [i,f] of fieldsInDisplayOrder){
      const card=document.createElement('details');card.className='nf-filter-field';card.dataset.field=i;card.open=this.openFields.has(i);const selected=selections(this.filters,f);const dates=dateSelection(this.filters,f);
      const chip=selected.map(v=>(f.values||[]).find(x=>x.value===v)?.label??String(v)).join(', ');
      card.innerHTML=`<summary>${esc(f.label)}</summary><div class="nf-chips" title="${esc(chip)}">${selected.length?esc(chip):f.type==='date'?'Período': 'Todos'}</div>`+(f.type==='date'?`<div class="nf-date-row"><label>De<input type="date" data-date-start="${i}" value="${esc(dates.start)}" ${f.min?`min="${esc(f.min)}"`:''} ${f.max?`max="${esc(f.max)}"`:''}></label><label>Até<input type="date" data-date-end="${i}" value="${esc(dates.end)}" ${f.min?`min="${esc(f.min)}"`:''} ${f.max?`max="${esc(f.max)}"`:''}></label></div><button class="nf-primary" data-apply-date="${i}">Aplicar período</button>`:`<input type="search" aria-label="Pesquisar ${esc(f.label)}" placeholder="Pesquisar opções…" data-search="${i}" value="${esc(this.searches[i]||'')}"><div class="nf-field-count" data-count="${i}"></div><div class="nf-values" data-values="${i}"></div>`)+`<button class="nf-field-clear" data-clear-field="${i}">Limpar seleção</button>`;
      grid.append(card);if(f.type!=='date')this.renderValues(i);
    }
    if(active!==undefined){const input=this.overlay.querySelector(`[data-search="${active}"]`);input?.focus();input?.setSelectionRange(input.value.length,input.value.length);}
  }
  renderValues(i){const f=this.config.fields[i],needle=normalized(this.searches[i]),all=f.values||[],selected=selections(this.filters,f);const matches=[];let count=0;for(let j=0;j<all.length;j++)if(!needle||normalized(all[j].label??all[j].value).includes(needle)){count++;if(matches.length<150)matches.push(j);}const mount=this.overlay.querySelector(`[data-values="${i}"]`);if(!mount)return;mount.innerHTML=matches.map(j=>`<label class="nf-value"><input type="checkbox" data-choice="${i}" data-index="${j}" ${selected.includes(all[j].value)?'checked':''}><span>${esc(all[j].label??all[j].value)}</span></label>`).join('');this.overlay.querySelector(`[data-count="${i}"]`).textContent=`${count} opções encontradas · ${all.length} no domínio${count>150?' · exibindo 150; refine a pesquisa':''}`;}
  keydown(e){if(this.orderDetailKey(e))return;if(e.key==='Escape'&&!this.overlay.hidden){if(this.job){this.job.cancelled=true;this.rejectWaiters(Error('Exportação cancelada.'));}else this.close();}if(e.key==='Tab'&&!this.overlay.hidden){const focus=[...this.overlay.querySelectorAll('button,input,select,summary,[tabindex="0"]')].filter(x=>!x.disabled&&x.getClientRects().length);if(!focus.length)return;const first=focus[0],last=focus.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}}
  rejectWaiters(error){for(const w of this.waiters){clearTimeout(w.timer);w.reject(error);}this.waiters=[];}
  currentExportFingerprint(){return this.config?exportFingerprint(this.config,this.filters,totalsFromHtml(this.footer,this.config.headers)):null;}
  checkExportContext(){
    const fingerprint=this.currentExportFingerprint();
    if(this.job&&fingerprint!==this.job.fingerprint){this.job.cancelled=true;this.job.reason='O recorte, os filtros ou os totais mudaram durante a exportação. Nenhum arquivo parcial foi baixado.';this.rejectWaiters(Error(this.job.reason));}
    if(this.downloadPlan&&fingerprint!==this.downloadPlanFingerprint){this.downloadPlan=null;this.downloadPlanFingerprint=null;if(this.overlayMode==='export'){for(const button of this.overlay.querySelectorAll('[data-action="export-copy"],[data-action="export-open"]'))button.disabled=true;const progress=this.overlay.querySelector('.nf-progress');if(progress)progress.textContent='O recorte mudou. Feche este painel e prepare o arquivo novamente.';}}
  }
  async requestPage(page){if(this.config.page===page)return {config:this.config,body:this.body,fingerprint:this.currentExportFingerprint()};this.job.touchedPages=true;const sequence=this.sequence;const ready=new Promise((resolve,reject)=>{const w={page,sequence,resolve,reject,timer:setTimeout(()=>{this.waiters=this.waiters.filter(x=>x!==w);reject(Error(`O Power BI não atualizou a página ${page} em 60 segundos. Nenhum arquivo parcial foi baixado.`));},60000)};this.waiters.push(w);});this.applyPage(page,this.job.view);return ready;}
  async export(all,include={data:true,totals:true}){
    if(this.job||this.pending||this.optionLoading||this.optionError||!this.config?.count)return;
    if(!include.data&&!include.totals){this.status('Selecione a tabela, os totais ou ambos para exportar.');return;}
    const original=JSON.parse(JSON.stringify(this.config)),originalFooter=this.footer,originalNumeric=(original.numericColumns||Array.from(this.root.querySelectorAll('.nf-table tbody tr:first-child td')).map(c=>c.classList.contains('num'))).slice(),job={origin:original.origin,view:original.view,page:original.page,pages:original.pages,count:original.count,revision:original.revision,fingerprint:this.currentExportFingerprint(),cancelled:false};this.downloadPlan=null;this.downloadPlanFingerprint=null;this.job=job;
    this.overlayMode='export';this.overlay.innerHTML='<h2>Exportando dados</h2><div class="nf-progress" role="status"></div><button class="nf-primary" data-action="cancel-export">Cancelar exportação</button>';this.render();
    try{
      const service=this.host.downloadService,exportMode=this.exportSettings?.production?EXPORT_MODES.production:EXPORT_MODES.desktop;
      await assertExportPermissions(this.host,exportMode);
      if(exportMode===EXPORT_MODES.desktop&&!service?.exportVisualsContentExtended&&!service?.exportVisualsContent)throw Error('A API de download não está disponível neste Power BI.');
      const dataRows=[];let rows=0;const pages=include.data?(all?Array.from({length:job.pages},(_,i)=>i+1):[job.page]):[];
      for(const page of pages){
        if(job.cancelled)throw Error(job.reason||'Exportação cancelada. Nenhum arquivo parcial foi baixado.');
        this.overlay.querySelector('.nf-progress').textContent=`Carregando página ${page} de ${job.pages}…`;
        const snapshot=await this.requestPage(page);if(job.cancelled)throw Error(job.reason||'Exportação cancelada.');
        if(snapshot.fingerprint!==job.fingerprint)throw Error('O recorte mudou durante a exportação. Nenhum arquivo parcial foi baixado.');
        const pageRows=extractRows(snapshot.body,original.headers),expected=Math.max(0,Math.min(500,job.count-(page-1)*500));if(pageRows.length!==expected)throw Error(`A página ${page} retornou ${pageRows.length} linhas; eram esperadas ${expected}. Nenhum arquivo parcial foi baixado.`);
        for(const row of pageRows){dataRows.push(row);rows++;}
      }
      if(include.data&&all&&rows!==job.count)throw Error('A quantidade exportada diverge do recorte. Download interrompido.');
      if(job.cancelled||this.currentExportFingerprint()!==job.fingerprint)throw Error(job.reason||'Exportação cancelada. Nenhum arquivo parcial foi baixado.');
      const sheets=[];if(include.data)sheets.push({name:job.view,headers:original.headers,rows:dataRows,numeric:originalNumeric});
      if(include.totals){const totals=totalsFromHtml(originalFooter,original.headers);if(!totals.length)throw Error('Os totais estruturados do filtro não foram encontrados no rodapé.');sheets.push({name:'Totais do filtro',headers:['Indicador','Valor'],rows:totals,numeric:[false,true]});}
      this.overlay.querySelector('.nf-progress').textContent='Preparando o arquivo Excel…';const bytes=makeXlsx(sheets.map(sheet=>({...sheet,title:`Relatório de Pedidos — ${original.title||job.origin} | ${sheet.name}`})));if(bytes.length>30*1024*1024)throw Error('O Excel ultrapassa 30 MB. Reduza os filtros antes de exportar. Nenhum arquivo parcial foi baixado.');
      const file=`Novaforma_${job.origin.replaceAll(' ','_')}_${job.view}_${all?'recorte_completo':'pagina_'+job.page}.xlsx`;
      if(exportMode===EXPORT_MODES.production){
        const plan=await prepareDownloadPlan(this.host,bytes,file,{exportMode,rows,pagesClipboardReady:this.exportSettings?.pagesClipboardReady});
        if(job.cancelled||this.currentExportFingerprint()!==job.fingerprint)throw Error(job.reason||'O recorte mudou. Prepare o arquivo novamente.');
        this.downloadPlan=plan;this.downloadPlanFingerprint=job.fingerprint;
        const copy=this.downloadPlan.transport==='clipboard';
        this.overlay.innerHTML=`<button class="nf-close" data-action="close">Fechar ×</button><h2>Arquivo preparado</h2><p>${rows.toLocaleString('pt-BR')} linhas. O download continua na página Novaforma.</p><div class="nf-progress" role="status">${copy?'Copie os dados e depois abra a página de download.':'Abra a página para baixar o Excel.'}</div>${copy?'<button class="nf-primary" data-action="export-copy">Copiar dados</button>':''}<button class="nf-primary" data-action="export-open" ${copy?'disabled':''}>Abrir página de download</button>`;
        return;
      }
      // API >=5.3 reports completion explicitly. Desktop's legacy boolean has
      // returned false after a successful, consented download; it cannot prove
      // that no file was saved. Never retry automatically or bypass host policy.
      // https://learn.microsoft.com/en-us/power-bi/developer/visuals/file-download-api
      let confirmed=false;
      if(typeof service.exportVisualsContentExtended==='function'){
        const result=await service.exportVisualsContentExtended(base64(bytes),file,'base64','Excel do recorte de pedidos e materiais');
        if(result?.downloadCompleted===false)throw Error('O Power BI informou que o download foi cancelado ou não foi concluído.');
        confirmed=result?.downloadCompleted===true;
      }else confirmed=(await service.exportVisualsContent(base64(bytes),file,'base64','Excel do recorte de pedidos e materiais'))===true;
      this.overlay.innerHTML=`<button class="nf-close" data-action="close">Fechar ×</button><h2>${confirmed?'Exportação concluída':'Arquivo enviado ao Power BI'}</h2><p>${rows.toLocaleString('pt-BR')} linhas enviadas ao download. ${confirmed?'':'Confira o arquivo na pasta de downloads após confirmar o diálogo do Power BI. '}A página original será restaurada.</p>`;
    }catch(error){this.overlay.innerHTML=`<button class="nf-close" data-action="close">Fechar ×</button><h2>Exportação não concluída</h2><p class="nf-error">${esc(error.message)}</p><p>A página original será restaurada.</p>`;}
    finally{this.job=null;this.rejectWaiters(Error('Exportação encerrada.'));if(!this.destroyed&&job.touchedPages&&this.currentExportFingerprint()===job.fingerprint)this.applyPage(job.page,job.view);if(!this.destroyed)this.render();}
  }
  getFormattingModel(){return {cards:[{displayName:'Exportação',uid:'nf-export-settings',groups:[{displayName:'Ambiente',uid:'nf-export-environment',slices:[{displayName:'Usar página de produção',uid:'nf-export-production',control:{type:'ToggleSwitch',properties:{descriptor:{objectName:'export',propertyName:'production'},value:!!this.exportSettings?.production}}},{displayName:'Página pronta para arquivos grandes',uid:'nf-export-clipboard',control:{type:'ToggleSwitch',properties:{descriptor:{objectName:'export',propertyName:'pagesClipboardReady'},value:!!this.exportSettings?.pagesClipboardReady}}}]}]}]};}
  destroy(){this.hideOrderDetail();this.downloadPlan=null;this.destroyed=true;if(this.job)this.job.cancelled=true;this.rejectWaiters(Error('O visual foi fechado.'));this.abort.abort();this.element.innerHTML='';}
}
