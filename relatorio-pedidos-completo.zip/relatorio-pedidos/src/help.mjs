import {esc} from './core.mjs';

// User-facing guidance only; no business rules, data changes or filter calls.
export function helpContent(config){
 const qa=(question,answer)=>`<div class="nf-help-qa"><h4>${question}</h4><p>${answer}</p></div>`;
 const section=(title,content)=>`<section class="nf-help-section"><h3>${title}</h3>${content}</section>`;
 const views=config.showViews===false
  ?'Esta página mostra a <b>Lista por material</b>: uma linha para cada combinação de pedido e código do material.'
  :'<b>Lista de pedidos</b> mostra uma linha por pedido. <b>Lista por material</b> mostra uma linha para cada combinação de pedido e código do material.';
 return `<div class="nf-help-heading"><div><h2>Dúvidas</h2><p>${esc(config.origin)} · ${config.view==='Materiais'?'Lista por material':'Lista de pedidos'}</p></div><button class="nf-help-return" data-action="close" title="Fechar a ajuda e voltar ao relatório com os mesmos filtros" aria-label="Voltar ao relatório">← Voltar ao relatório</button></div><div class="nf-help-grid">`+
 section('Começar',
  qa('Por onde começo?','Escolha Vendido para consultar as vendas, Em Aberto para consultar a carteira pendente ou Bloqueado para consultar pedidos bloqueados. Depois escolha a lista e os filtros.')+
  qa('Qual lista devo usar?',views)+
  qa('Por que um pedido aparece mais de uma vez?','Na Lista por material, o mesmo pedido pode ter vários códigos de material. Essa repetição é esperada.')+
  (config.showViews===false?'':qa('Posso trocar de lista sem perder os filtros?','Sim. Ao alternar as duas listas nesta página, os filtros são mantidos. Cada lista tem sua própria página de navegação.'))+
  qa('Os filtros são iguais nas três abas?','Cada aba — Vendido, Em Aberto e Bloqueado — mantém seus próprios filtros. Os filtros não são sincronizados entre as abas.'))+
 section('Filtrar',
  qa('Digitei um valor. Por que a lista não mudou?','Digitar serve para pesquisar as opções. <b>Marque a caixa</b> ao lado do valor desejado para aplicar o filtro.')+
  qa('Posso combinar filtros?','Sim. Você pode marcar vários valores e combinar campos, como pedido, cliente e UF. Use <b>Limpar seleção</b> no campo que deseja remover.')+
  qa('Qual data devo escolher?','<b>Data Entrada</b> filtra a entrada do pedido. <b>Data APP</b> usa a data APP do faturamento e a data da cotação da carteira. <b>Data Faturamento</b> filtra o faturamento. Preencha o campo desejado e clique em <b>Aplicar período</b>.')+
  qa('O que indica o período acima da lista?','O texto mostra automaticamente <b>Data Entrada</b>, <b>Data APP</b> e <b>Data Faturamento</b>, nesta ordem. “Sem restrição de data” indica que aquele campo não tem um período aplicado. “Inclui sem data” avisa que o recorte também admite registros sem essa data.')+
  qa('12M é o mesmo que o ano de 2026?','Não. <b>12M</b> é um intervalo de 12 meses e pode atravessar dois anos. Confira as datas efetivas acima da lista; selecionar o ano de 2026 corresponde a outro recorte.')+
  qa('Limpei uma data. Por que a lista continua restrita?','Os filtros são combinados: um registro precisa atender aos filtros aplicáveis. Limpar um campo mantém os demais, inclusive outros períodos. Confira os três períodos e limpe cada seleção que deseja remover.')+
  qa('Como aparecem novos meses e anos?','Novas datas e registros ficam disponíveis após a atualização da base no Power BI. As colunas da lista mantêm seu significado. Se você escolheu um período, ele continua aplicado até ser alterado ou limpo.')+
  qa('As opções ainda estão carregando. O que faço?','Aguarde a conclusão para selecionar filtros e exportar. A lista pode aparecer antes de todas as opções ficarem disponíveis.'))+
 section('Entender a tabela',
  qa('A lista terminou em 500 linhas?', 'Cada página mostra até <b>500 linhas</b>. Use o seletor <b>Página</b> acima da tabela para continuar.')+
  qa('O total corresponde só à página atual?','Os <b>totais do filtro</b> consideram todas as linhas do recorte selecionado, incluindo as outras páginas.')+
  qa('O que significa Em aberto?','Na Lista de pedidos de Vendido, <b>Em aberto</b> é o novo nome da coluna antes chamada “Aguard. Fat”. A troca do nome não altera os valores.')+
  qa('Por que existem valores negativos ou um material zerado com status Faturado?','Devoluções podem produzir valores negativos ou zerar um material. O faturamento considera o valor líquido das devoluções. O <b>Status</b> é avaliado para o pedido completo e é compartilhado por seus materiais; um pedido com faturamento anterior e devolução integral, sem carteira, pode aparecer como Faturado.')+
  qa('Como vejo as colunas e os textos completos?','Use a barra de rolagem horizontal para ver as colunas à direita. Passe o mouse sobre uma célula para ler seu texto completo.'))+
 section('Exportar',
  qa('Como escolho o que baixar?', 'No topo, abra <b>Dados para exportar</b>. Escolha <b>Página atual</b> ou <b>Todo o recorte</b>. Marque a tabela e/ou <b>Totais do filtro</b> e clique em <b>Baixar Excel</b>.')+
  qa('Como termino o download?', 'Aguarde a preparação de todas as páginas; exportar todo o recorte pode levar mais tempo. Sua página original será restaurada. No Desktop, confirme o download na janela do Power BI. Quando aparecer <b>Abrir página de download</b>, clique para continuar no navegador. Se aparecer <b>Copiar dados</b>, copie primeiro, abra a página e use <b>Colar dados</b> para baixar o Excel completo.')+
  qa('O que acontece se eu cancelar?', 'Se cancelar durante a preparação, nenhum arquivo parcial será baixado. Depois de abrir a página de download ou a confirmação do Power BI, siga as opções dessa janela. Se os filtros mudarem durante a preparação, prepare o arquivo novamente.'))+
 '</div>';
}
