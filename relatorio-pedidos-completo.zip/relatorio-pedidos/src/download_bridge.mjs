import {deflateSync} from 'fflate';

export const EXPORT_MODES=Object.freeze({desktop:'desktopNative',production:'githubPages'});
export const DOWNLOAD_PAGE='https://inteligenciadevendasnovaforma.github.io/novaforma-bi-exportar/download-page/';
export const XLSX_MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
export const MAX_XLSX_BYTES=30*1024*1024;
export const MAX_URL_LENGTH=2500;
export const XLSX_CLIPBOARD_PREFIX='NFXLSX1.';
const copiedPlans=new WeakSet();

// Compare semantic selections independent of JSON property/set ordering. Only
// the two technical page selectors are omitted; business/date/view filters stay.
const canonical=value=>Array.isArray(value)?value.map(canonical).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])])):value;
export function exportFingerprint(config,filters,totals=[]){
 const semantic=(filters||[]).filter(f=>!(f?.target?.column==='Pagina'&&['d_HTML_Pagina_Pedidos','d_HTML_Pagina_Materiais'].includes(f.target.table)));
 return JSON.stringify([config.origin,config.view,config.count,config.pages,config.revision,config.headers,config.numericColumns??null,config.analysisPeriods??null,canonical(semantic),totals]);
}
const checkCurrent=isCurrent=>{if(isCurrent&&!isCurrent())throw Error('O recorte mudou. Prepare o arquivo novamente antes de continuar.');};

const encoded=bytes=>{let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s);};
const b64url=bytes=>encoded(bytes).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
const fileName=value=>{const s=String(value||'Novaforma_pedidos.xlsx').replace(/[\x00-\x1f\\/:*?"<>|]/g,'_').slice(0,180);return /\.xlsx$/i.test(s)?s:s+'.xlsx';};
const needClick=event=>{if(event?.type!=='click'||event?.isTrusted!==true||globalThis.navigator?.userActivation?.isActive===false)throw Error('Use o botão do relatório para continuar a exportação.');};

/** Explicit mode only: never infer Desktop/Service from an unreliable host hint. */
export async function assertExportPermissions(host,exportMode){
 if(!Object.values(EXPORT_MODES).includes(exportMode))throw Error('Configure exportMode como desktopNative ou githubPages.');
 if(typeof host?.downloadService?.exportStatus!=='function')throw Error('O Power BI não informou a permissão de exportação.');
 const status=await host.downloadService.exportStatus();
 if(status!==0)throw Error(status===3?'O administrador do Power BI bloqueou a exportação. Nenhuma página foi aberta ou dado copiado.':status===1?'A permissão ExportContent não foi declarada no visual.':'A exportação não é permitida ou não é suportada neste ambiente.');
 if(exportMode===EXPORT_MODES.production){
  if(typeof host?.webAccessService?.webAccessStatus!=='function')throw Error('O Power BI não informou a permissão de acesso à página de produção.');
  if(await host.webAccessService.webAccessStatus(DOWNLOAD_PAGE)!==0)throw Error('O acesso à página de produção não está permitido pelo Power BI.');
 }
}

/** Existing XLSX bytes are transported unchanged: arbitrary columns, types and totals. */
export async function prepareDownloadPlan(host,bytes,name,{exportMode,rows=0,pagesClipboardReady=false}={}){
 await assertExportPermissions(host,exportMode);
 if(!(bytes instanceof Uint8Array)||bytes.length<4||bytes[0]!==80||bytes[1]!==75||bytes[2]!==3||bytes[3]!==4)throw Error('O arquivo Excel preparado não contém um XLSX válido.');
 if(bytes.length>MAX_XLSX_BYTES)throw Error('O Excel ultrapassa 30 MB. Nenhum arquivo parcial será enviado.');
 if(!Number.isSafeInteger(rows)||rows<0)throw Error('A contagem de linhas para exportação é inválida.');
 const filename=fileName(name),base={exportMode,filename,rows,bytesLength:bytes.length};
 if(exportMode===EXPORT_MODES.desktop)return Object.freeze({...base,transport:'native',bytes:bytes.slice()});
 const data=b64url(deflateSync(bytes,{level:6})),direct=DOWNLOAD_PAGE+'#'+new URLSearchParams({d:data,c:'1',n:filename}).toString();
 if(direct.length<=MAX_URL_LENGTH)return Object.freeze({...base,transport:'fragment',url:direct});
 // The public page must have the NFXLSX1 patch before enabling this route.
 if(!pagesClipboardReady)throw Error('O arquivo completo requer a atualização NFXLSX1 da página de produção. Nenhum dado foi copiado ou página aberta.');
 const url=DOWNLOAD_PAGE+'#'+new URLSearchParams({k:'cola',n:filename,q:String(rows)}).toString();
 if(url.length>MAX_URL_LENGTH)throw Error('O endereço de exportação ultrapassa o limite permitido.');
 return Object.freeze({...base,transport:'clipboard',url,clipboardText:XLSX_CLIPBOARD_PREFIX+data});
}

/** Use a fresh click after preparation; browsers may revoke clipboard activation during paging. */
export async function copyPlanPayload(host,plan,event,{clipboard=globalThis.navigator?.clipboard,isCurrent}={}){
 needClick(event);if(plan?.exportMode!==EXPORT_MODES.production||plan.transport!=='clipboard')throw Error('Este arquivo não requer cópia para a página.');
 if(typeof plan.clipboardText!=='string'||!plan.clipboardText.startsWith(XLSX_CLIPBOARD_PREFIX))throw Error('O texto completo do Excel não foi preparado corretamente.');
 await assertExportPermissions(host,plan.exportMode);
 checkCurrent(isCurrent);
 if(typeof clipboard?.writeText!=='function')throw Error('A cópia não está disponível neste ambiente. Nenhum dado foi enviado.');
 try{await clipboard.writeText(plan.clipboardText);}catch{throw Error('O navegador não permitiu copiar o arquivo. Clique novamente em Copiar dados; nenhuma página foi aberta.');}
 copiedPlans.add(plan);return {copied:true,rows:plan.rows};
}

/** Separate explicit user click, including after clipboard success. No automatic launch on update. */
export async function launchDownloadPlan(host,plan,event,{isCurrent}={}){
 needClick(event);if(plan?.exportMode!==EXPORT_MODES.production||!plan.url)throw Error('A página não está configurada para esta exportação.');
 if(!plan.url.startsWith(DOWNLOAD_PAGE+'#')||plan.url.length>MAX_URL_LENGTH)throw Error('O endereço não corresponde à página de produção aprovada.');
 if(plan.transport==='clipboard'&&!copiedPlans.has(plan))throw Error('Copie os dados pelo botão do relatório antes de abrir a página.');
 await assertExportPermissions(host,plan.exportMode);
 checkCurrent(isCurrent);
 if(typeof host.launchUrl!=='function')throw Error('O Power BI não oferece abertura da página neste ambiente.');
 host.launchUrl(plan.url);return {opened:true,transport:plan.transport};
}

/** Optional native adapter. Root may retain its existing native branch instead. */
export async function sendNativeDownload(host,plan){
 if(plan?.exportMode!==EXPORT_MODES.desktop||plan.transport!=='native')throw Error('A exportação não está no modo nativo do Desktop.');
 await assertExportPermissions(host,plan.exportMode);
 const service=host.downloadService;
 if(typeof service.exportVisualsContentExtended==='function'){
  const result=await service.exportVisualsContentExtended(encoded(plan.bytes),plan.filename,'base64','Excel do recorte de pedidos e materiais');
  if(result?.downloadCompleted===false)throw Error('O Power BI informou que o download foi cancelado ou não foi concluído.');
  return {confirmed:result?.downloadCompleted===true};
 }
 if(typeof service.exportVisualsContent!=='function')throw Error('A API de download nativo não está disponível.');
 return {confirmed:(await service.exportVisualsContent(encoded(plan.bytes),plan.filename,'base64','Excel do recorte de pedidos e materiais'))===true};
}
